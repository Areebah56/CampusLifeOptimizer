export default function CampusLifeOptimizer() {
  return (
    <div>
      {/* Landing Page */}
      <section className="text-center py-20">
        <h1 className="text-5xl font-bold mb-4">Optimize Your Campus Life</h1>
        <p className="text-lg mb-6">Your all-in-one platform for smarter campus living.</p>
        <div className="flex justify-center gap-4">
          <button className="px-4 py-2 bg-blue-600 text-white rounded">Login</button>
          <button className="px-4 py-2 border border-blue-600 text-blue-600 rounded">Sign Up</button>
        </div>
      </section>

      {/* Dashboard */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Sidebar */}
        <div className="md:col-span-1 bg-white rounded-2xl shadow p-4">
          <h2 className="text-2xl font-semibold mb-4">Menu</h2>
          <ul className="space-y-2">
            {['Smart Schedule', 'Resources', 'Navigation', 'Study Groups', 'Lost & Found', 'Events', 'Meals'].map((item) => (
              <li key={item} className="p-2 rounded hover:bg-blue-100 cursor-pointer">{item}</li>
            ))}
          </ul>
        </div>

        {/* Main Content */}
        <div className="md:col-span-3 space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Dashboard</h2>
            <button className="px-4 py-2 bg-gray-300 rounded">Profile</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {['View Timetable', 'Share Resource', 'Find Events', 'Order Meals'].map((action) => (
              <div key={action} className="bg-white p-6 rounded-2xl shadow text-center font-semibold hover:scale-105 transition">{action}</div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
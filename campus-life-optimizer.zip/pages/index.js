import CampusLifeOptimizer from '@/components/CampusLifeOptimizer'

export default function Home() {
  return <CampusLifeOptimizer />
}